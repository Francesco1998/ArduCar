/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webserviceclient;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;


/**
 *
 * @author alex
 */
public class WebServiceClient {

private static BufferedReader Input = 
        new BufferedReader(new InputStreamReader(System.in));
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String user="";
        String psw="";
        String v= "Username gia presente";
        
        do{    
            System.out.print("Username : " ); 
            // leggo una riga di input 
            user = Input.readLine();

            System.out.print("Password : " ); 
            // leggo una riga di input 
            psw = Input.readLine();
            
            System.out.print(login(user,psw)+"\n"+"\n"+"\n"); 
        }while(login(user,psw).equals(v));
        
    }

    private static String login(java.lang.String id, java.lang.String psw) {
        org.catta.login.ProviderLogin_Service service = new org.catta.login.ProviderLogin_Service();
        org.catta.login.ProviderLogin port = service.getProviderLoginPort();
        return port.login(id, psw);
    }
   }

